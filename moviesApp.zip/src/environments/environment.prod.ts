export const environment = {
  production: true,
  apiBaseUrl: `https://api.themoviedb.org/3/genre`,
  options: {
    params: {
      api_key: '68e82445c8842ba8616d0f6bf0e97a41'
    }
  }
};
